create definer = root@localhost view usee_tasks as
select `todotask`.`users`.`id`             AS `id`,
       `todotask`.`users`.`Name`           AS `Name`,
       count(`todotask`.`tasks`.`user_id`) AS `tasks_num`,
       sum(`todotask`.`tasks`.`checked`)   AS `done`
from (`todotask`.`users` left join `todotask`.`tasks` on (`todotask`.`users`.`id` = `todotask`.`tasks`.`user_id`))
group by `todotask`.`users`.`Name`;

